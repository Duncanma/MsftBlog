﻿namespace AudioTranscription
{
	partial class mainTranscriber
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.btnLoadRecording = new System.Windows.Forms.Button();
			this.openAudioFile = new System.Windows.Forms.OpenFileDialog();
			this.transcript = new System.Windows.Forms.RichTextBox();
			this.togglePlayPause = new System.Windows.Forms.Button();
			this.copyText = new System.Windows.Forms.Button();
			this.currentPosition = new System.Windows.Forms.Label();
			this.positionTimer = new System.Windows.Forms.Timer(this.components);
			this.videoProgress = new System.Windows.Forms.TrackBar();
			this.autoSave = new System.Windows.Forms.Timer(this.components);
			this.statusStrip1 = new System.Windows.Forms.StatusStrip();
			this.statusLabel = new System.Windows.Forms.ToolStripStatusLabel();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.saveTranscript = new System.Windows.Forms.Button();
			this.saveTranscriptFile = new System.Windows.Forms.SaveFileDialog();
			this.secondsToJump = new System.Windows.Forms.NumericUpDown();
			this.lblSeconds = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.videoProgress)).BeginInit();
			this.statusStrip1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.secondsToJump)).BeginInit();
			this.SuspendLayout();
			// 
			// btnLoadRecording
			// 
			this.btnLoadRecording.Location = new System.Drawing.Point(12, 13);
			this.btnLoadRecording.Name = "btnLoadRecording";
			this.btnLoadRecording.Size = new System.Drawing.Size(133, 23);
			this.btnLoadRecording.TabIndex = 0;
			this.btnLoadRecording.Text = "Load Recording";
			this.btnLoadRecording.UseVisualStyleBackColor = true;
			this.btnLoadRecording.Click += new System.EventHandler(this.btnLoadRecording_Click);
			// 
			// openAudioFile
			// 
			this.openAudioFile.Filter = "WAV files|*.wav|All files|*.*";
			// 
			// transcript
			// 
			this.transcript.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.transcript.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.transcript.Location = new System.Drawing.Point(163, 13);
			this.transcript.Name = "transcript";
			this.transcript.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
			this.transcript.Size = new System.Drawing.Size(281, 380);
			this.transcript.TabIndex = 1;
			this.transcript.Text = "";
			// 
			// togglePlayPause
			// 
			this.togglePlayPause.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.togglePlayPause.Enabled = false;
			this.togglePlayPause.Location = new System.Drawing.Point(12, 399);
			this.togglePlayPause.Name = "togglePlayPause";
			this.togglePlayPause.Size = new System.Drawing.Size(61, 31);
			this.togglePlayPause.TabIndex = 3;
			this.togglePlayPause.Text = "Play";
			this.togglePlayPause.UseVisualStyleBackColor = true;
			this.togglePlayPause.Click += new System.EventHandler(this.togglePlayPause_Click);
			// 
			// copyText
			// 
			this.copyText.Location = new System.Drawing.Point(12, 95);
			this.copyText.Name = "copyText";
			this.copyText.Size = new System.Drawing.Size(133, 23);
			this.copyText.TabIndex = 6;
			this.copyText.Text = "Copy Text";
			this.copyText.UseVisualStyleBackColor = true;
			this.copyText.Click += new System.EventHandler(this.copyText_Click);
			// 
			// currentPosition
			// 
			this.currentPosition.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.currentPosition.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.currentPosition.Location = new System.Drawing.Point(12, 352);
			this.currentPosition.Name = "currentPosition";
			this.currentPosition.Size = new System.Drawing.Size(133, 23);
			this.currentPosition.TabIndex = 7;
			this.currentPosition.Text = "00:00:00";
			this.currentPosition.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// positionTimer
			// 
			this.positionTimer.Enabled = true;
			this.positionTimer.Interval = 500;
			this.positionTimer.Tick += new System.EventHandler(this.positionTimer_Tick);
			// 
			// videoProgress
			// 
			this.videoProgress.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.videoProgress.Enabled = false;
			this.videoProgress.LargeChange = 20;
			this.videoProgress.Location = new System.Drawing.Point(79, 399);
			this.videoProgress.Maximum = 100;
			this.videoProgress.Name = "videoProgress";
			this.videoProgress.Size = new System.Drawing.Size(365, 45);
			this.videoProgress.TabIndex = 5;
			this.videoProgress.TickFrequency = 10;
			this.videoProgress.Scroll += new System.EventHandler(this.videoProgress_Scroll);
			this.videoProgress.ValueChanged += new System.EventHandler(this.videoProgress_ValueChanged);
			// 
			// autoSave
			// 
			this.autoSave.Enabled = true;
			this.autoSave.Interval = 5000;
			this.autoSave.Tick += new System.EventHandler(this.autoSave_Tick);
			// 
			// statusStrip1
			// 
			this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.statusLabel});
			this.statusStrip1.Location = new System.Drawing.Point(0, 446);
			this.statusStrip1.Name = "statusStrip1";
			this.statusStrip1.Size = new System.Drawing.Size(456, 22);
			this.statusStrip1.TabIndex = 8;
			this.statusStrip1.Text = "statusStrip1";
			// 
			// statusLabel
			// 
			this.statusLabel.Name = "statusLabel";
			this.statusLabel.Size = new System.Drawing.Size(0, 17);
			// 
			// textBox1
			// 
			this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox1.Location = new System.Drawing.Point(13, 125);
			this.textBox1.Multiline = true;
			this.textBox1.Name = "textBox1";
			this.textBox1.ReadOnly = true;
			this.textBox1.Size = new System.Drawing.Size(132, 177);
			this.textBox1.TabIndex = 9;
			this.textBox1.Text = "Press \"Tab\" to pause\r\n\r\nPress \"Tab\" again to jump back 5 seconds and restart the " +
    "audio\r\n\r\nPress the \\ key to just jump back 5 seconds, no pause";
			// 
			// label1
			// 
			this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(12, 320);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(133, 23);
			this.label1.TabIndex = 10;
			this.label1.Text = "Position:";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// saveTranscript
			// 
			this.saveTranscript.Location = new System.Drawing.Point(12, 54);
			this.saveTranscript.Name = "saveTranscript";
			this.saveTranscript.Size = new System.Drawing.Size(133, 23);
			this.saveTranscript.TabIndex = 11;
			this.saveTranscript.Text = "Save Transcript";
			this.saveTranscript.UseVisualStyleBackColor = true;
			this.saveTranscript.Click += new System.EventHandler(this.saveTranscript_Click);
			// 
			// saveTranscriptFile
			// 
			this.saveTranscriptFile.DefaultExt = "rtf";
			this.saveTranscriptFile.FileName = "transcript.rtf";
			this.saveTranscriptFile.Filter = "RTF file|*.rtf";
			this.saveTranscriptFile.Title = "Save Transcript As";
			// 
			// secondsToJump
			// 
			this.secondsToJump.Location = new System.Drawing.Point(95, 287);
			this.secondsToJump.Name = "secondsToJump";
			this.secondsToJump.Size = new System.Drawing.Size(50, 20);
			this.secondsToJump.TabIndex = 12;
			this.secondsToJump.ValueChanged += new System.EventHandler(this.secondsToJump_ValueChanged);
			// 
			// lblSeconds
			// 
			this.lblSeconds.AutoSize = true;
			this.lblSeconds.Location = new System.Drawing.Point(9, 289);
			this.lblSeconds.Name = "lblSeconds";
			this.lblSeconds.Size = new System.Drawing.Size(52, 13);
			this.lblSeconds.TabIndex = 13;
			this.lblSeconds.Text = "Seconds:";
			// 
			// mainTranscriber
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(456, 468);
			this.Controls.Add(this.lblSeconds);
			this.Controls.Add(this.secondsToJump);
			this.Controls.Add(this.saveTranscript);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.statusStrip1);
			this.Controls.Add(this.currentPosition);
			this.Controls.Add(this.copyText);
			this.Controls.Add(this.videoProgress);
			this.Controls.Add(this.togglePlayPause);
			this.Controls.Add(this.transcript);
			this.Controls.Add(this.btnLoadRecording);
			this.MinimumSize = new System.Drawing.Size(472, 507);
			this.Name = "mainTranscriber";
			this.Text = "Transcriber";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.mainTranscriber_FormClosing);
			this.Load += new System.EventHandler(this.mainTranscriber_Load);
			this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mainTranscriber_KeyDown);
			((System.ComponentModel.ISupportInitialize)(this.videoProgress)).EndInit();
			this.statusStrip1.ResumeLayout(false);
			this.statusStrip1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.secondsToJump)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnLoadRecording;
		private System.Windows.Forms.OpenFileDialog openAudioFile;
		private System.Windows.Forms.RichTextBox transcript;
		private System.Windows.Forms.Button togglePlayPause;
		private System.Windows.Forms.Button copyText;
		private System.Windows.Forms.Label currentPosition;
		private System.Windows.Forms.Timer positionTimer;
		private System.Windows.Forms.TrackBar videoProgress;
		private System.Windows.Forms.Timer autoSave;
		private System.Windows.Forms.StatusStrip statusStrip1;
		private System.Windows.Forms.ToolStripStatusLabel statusLabel;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button saveTranscript;
		private System.Windows.Forms.SaveFileDialog saveTranscriptFile;
		private System.Windows.Forms.NumericUpDown secondsToJump;
		private System.Windows.Forms.Label lblSeconds;
	}
}

